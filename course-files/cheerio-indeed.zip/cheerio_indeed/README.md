1) Type `npm install`
2) Type `node app.js`